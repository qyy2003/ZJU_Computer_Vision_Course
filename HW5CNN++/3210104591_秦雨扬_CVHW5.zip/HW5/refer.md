https://pytorch.org/tutorials/beginner/basics/data_tutorial.html



https://stackoverflow.com/questions/57565234/pil-not-always-using-3-channels-for-png

https://stackoverflow.com/questions/51923503/why-do-some-images-have-third-dimension-3-while-others-have-4